package com.salesianos.triana.E08_Herencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E08HerenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(E08HerenciaApplication.class, args);
	}

}
