package com.salesianos.triana.E08_Herencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E08HerenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
